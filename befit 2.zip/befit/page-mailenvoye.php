<?php get_header(); ?>

<br><br><br><br><br><br>
<h1 class="display-3 text-blue ml-5 font-weight-bold">Un mail a bien été envoyé à cette adresse !</h1>

<button class="mt-5" id="connect_button_form" id="back_to_connexion">Connexion</button>

</body>
</html>